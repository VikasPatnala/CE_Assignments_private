#include <iostream>

int main() {
    int a, b, sum = 0;
    std::cin >> a >> b;
    sum = a + b;
    std::cout << sum << std::endl;
    return 0;
}
