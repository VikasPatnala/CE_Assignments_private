#include <iostream>

int main() {
    int a = 1, b = 2;

    int res = (a > b) ? a : b;

    std::cout << res << std::endl;
}