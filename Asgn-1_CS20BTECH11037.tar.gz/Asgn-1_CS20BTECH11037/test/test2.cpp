#include <iostream>

using namespace std;

int main() {
    int a, b;
    cin >> a >> b;
    double p, q;
    cin >> p >> q;
    a = a + b;
    b = a - b;
    p = a + q;
    q = p + b;
    a = q;
    p = a + b;
}