#include <iostream>

using namespace std;

int main() {
    int a = 2;
    int b = 3;
    int c = 0;
    c = a + b;
    c = a - b;
    c = a * b;
    c = a / b;
    c = a % b;
    cout << c;
}