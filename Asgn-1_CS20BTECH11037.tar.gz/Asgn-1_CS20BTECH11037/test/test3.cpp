#include <iostream>

using namespace std;

int main() {
    short a = 1, b = 3;
    unsigned c = 6, d = 9;
    int e = 3, f = 4;
    long m = 156, n = 897;
    long long o = 90000, p = 98274;
    float g = 7.8, h = 9.6;
    double i = 2.4, j = 6.7;
    long double k = 1.76, l = 4.56;
    
    a = a + b;
    a = a - b;
    a = a / b;
    a = a * b;
    a = a % b;

    c = c + d;
    c = c - d;
    c = c / d;
    c = c * d;
    c = c % d;

    e = e + f;
    e = e - f;
    e = e / f;
    e = e * f;
    e = e % f;

    m = m + n;
    m = m - n;
    m = m / n;
    m = m * n;
    m = m % n;

    o = o + p;
    o = o - p;
    o = o / p;
    o = o * p;
    o = o % p;

    g = g + h;
    g = g - h;
    g = g * h;
    g = g / h;

    i = i + j;
    i = i - j;
    i = i * j;
    i = i / j;

    k = k + l;
    k = k - l;
    k = k * l;
    k = k / l;
}