#include <iostream>

void fun() {
	long double a = 1, b = 2;
	long double c = a + b, d = a - b, f = a / b;
	std::cout << c << d << f;	
}

void loop() {
    int a = 1;
    for (int i = 0; i <= 100; ++i) {
        a = a + 2;
    }
    
    for (int i = 0; 100 > i; ++i) {
        a = a + 3;
    }

    int b = 50;
    for (int i = 100; i > 0; --i) {
        b -= 2;
    }

    for (int i = 100; 0 < i; --i) {
        b = b + 3;
    }
    std::cout << a << b;
}

int main() {
    int a, b, sum = 0;
    std::cin >> a >> b;
    sum = a + b;
    std::cout << sum << std::endl;
    int c = a - b;
    int d = a % b;
    int f = a / b;
    double e = 23.45;
    double g = 45.6;
    double h = e / g;
    double i = e - g;
    std::cout << c  << d << f << e << g << h << i << "\n";

    loop();

    return 0;
}
