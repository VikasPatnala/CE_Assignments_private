BUILD_DIR=../llvm-project/build

OPT=$BUILD_DIR/bin/opt
CLANG=$BUILD_DIR/bin/clang
CLANGPP=$BUILD_DIR/bin/clang++

SRC_DIR=./
LL_OUT_DIR=./


FLAG="-Xclang -disable-O0-optnone"

# generating .ll files in the ll_outs directory
$CLANGPP -S -emit-llvm $SRC_DIR/test1.cpp -o $LL_OUT_DIR/test1.ll $FLAG
$CLANGPP -S -emit-llvm $SRC_DIR/test2.cpp -o $LL_OUT_DIR/test2.ll $FLAG
$CLANGPP -S -emit-llvm $SRC_DIR/test3.cpp -o $LL_OUT_DIR/test3.ll $FLAG
$CLANGPP -S -emit-llvm $SRC_DIR/test4.cpp -o $LL_OUT_DIR/test4.ll $FLAG
$CLANGPP -S -emit-llvm $SRC_DIR/test5.cpp -o $LL_OUT_DIR/test5.ll $FLAG