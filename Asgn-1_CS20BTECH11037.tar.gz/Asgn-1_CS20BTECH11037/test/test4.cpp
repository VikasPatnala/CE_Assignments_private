#include <iostream>

using namespace std;

void fun1() {
    int a = 1, b = 2;
    for (int i = 0; i < 100; ++i) {
        a = a + b;
    }
    std::cout << a << " " << b << "\n";
}

int main() {
    fun1();
}