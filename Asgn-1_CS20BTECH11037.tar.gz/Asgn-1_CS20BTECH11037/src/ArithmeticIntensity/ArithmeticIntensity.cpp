#include "llvm/IR/LegacyPassManager.h"
#include "llvm/Passes/PassBuilder.h"
#include "llvm/Passes/PassPlugin.h"
#include "llvm/Support/raw_ostream.h"
#include "llvm/Demangle/Demangle.h"
#include "llvm/IR/Type.h"
#include "llvm/IR/CFG.h"

using namespace llvm;

namespace {

/// This if condition is used to check the instruction is BinaryOperator
/// There are 12 BinaryOperators which are
/// Add, FAdd, Sub, FSub, Mul, FMul, UDiv, SDiv, FDiv, URem, SRem, FRem
/// and these are defined as constants in "Instruction.def" file so
/// value of Opcode should be inbetween Instruction::Add and Instruction::FRem
bool isArithmeticOp(unsigned Opcode) {
  if (Opcode >= Instruction::Add && Opcode <= Instruction::FRem) 
    return true;
  return false;
}

/// Checking whether the inst is LoadInst or StoreInst using dyn_cast
bool isMemoryOp(Instruction &I) {
  if (dyn_cast<LoadInst>(&I) || dyn_cast<StoreInst>(&I)) 
    return true;
  return false;
}

/// Function to the initial value of the Loop induction Var when the loop starts
int getLoopStart(BasicBlock *BB) {
  int loopStart = 0;
  for (BasicBlock *Pred : predecessors(BB)) {
    for (auto &I : *Pred) {
      if (auto *SI = dyn_cast<StoreInst>(&I)) {
        if (auto *CI = dyn_cast<ConstantInt>(SI->getValueOperand())) {
          loopStart = CI->getSExtValue();
        }
      }
    }
  }
  return loopStart;
}

/// Function to get the final value of the Loop induction Var when the loop ends
int getLoopEnd(ICmpInst* CmpI) {
  // var to store the end value
  int loopEnd = 0;
  
  Value *LHS = CmpI->getOperand(0), *RHS = CmpI->getOperand(1);

  // the cond can be of four types
  // i > 100 or 100 < i or i < 100 or 100 > i
  // we will check these four conds below
  if (auto *CI = dyn_cast<ConstantInt>(RHS)) {
    loopEnd = CI->getSExtValue();
    if (CmpI->getPredicate() == ICmpInst::ICMP_SLT)
      loopEnd -= 1;
    if (CmpI->getPredicate() == ICmpInst::ICMP_SGT)
      loopEnd += 1;
  } else if (auto *CI = dyn_cast<ConstantInt>(LHS)) {
    loopEnd = CI->getSExtValue();
    if (CmpI->getPredicate() == ICmpInst::ICMP_SGT)
      loopEnd -= 1;
    if (CmpI->getPredicate() == ICmpInst::ICMP_SLT)
      loopEnd += 1;
  }

  return loopEnd;
}

/// Checks whether the basic block is loop header or not
/// As we are give that loop have only depth directly 
/// Checking the backedge will be sufficent
int isLoop(BasicBlock *BB) {
  if (auto *BI = dyn_cast<BranchInst>(&BB->back())) {
    if (BI->isConditional()) {
      if (BI->getSuccessor(0)->getSinglePredecessor() == BB) {
        Value *cond = BI->getCondition();
        int loopEnd = 0;
        if (auto *CmpI = dyn_cast<ICmpInst>(cond)) {
          loopEnd = getLoopEnd(CmpI);
        }
        int loopStart = getLoopStart(BB);
        int loopCount = 0;
        if (loopStart <= loopEnd) {
          loopCount = loopEnd - loopStart + 1;
        } else {
          loopCount = loopStart - loopEnd + 1;
        }
        // errs() << "# of times loop will execute = " << loopCount
        //         << "\n";
        return loopCount;
      }
    }
  }
  return -1;
}

void visitor(Function &F) {
  // A : # of Arithmetic operations
  // B : # of Bytes of memory accesses
  int A = 0, B = 0;
  int noOfLoops = 0;
  std::vector<int> loopCounts;
  for (BasicBlock &BB : F) {
    int loopCount = isLoop(&BB);
    if (loopCount != -1) {
      noOfLoops++;
      loopCounts.push_back(loopCount);
    }
    for (Instruction &I : BB) {
      if (isArithmeticOp(I.getOpcode())) {
        A++;
      } else if (isMemoryOp(I)) {
        B++;
      }
    }
  }
  errs() << "-----------------" << demangle(F.getName()) << "-----------------\n";
  if (noOfLoops) {
    errs() << "This function contains " << noOfLoops << " loops\n";
    for (int i = 0; i < (int)loopCounts.size(); ++i) {
      errs() << "The " << i + 1 << "th loop iterates " << loopCounts[i] << " times\n";
    }
  }
  errs() << "# of Arithmetic ops " << A << "\n";
  errs() << "# of bytes accessed " << B << "\n";
  
  double AI = (B > 0) ? (A / (double)B) : 0;
  errs() << "Arithmetic Intensity A/B : " << AI << "\n";
}

struct ArithmeticIntensity : PassInfoMixin<ArithmeticIntensity> {
  PreservedAnalyses run(Function &F, FunctionAnalysisManager &) {
    visitor(F);
    return PreservedAnalyses::all();
  }
  static bool isRequired() { return true; }
};
}

llvm::PassPluginLibraryInfo getArithmeticIntensityPluginInfo() {
  return {LLVM_PLUGIN_API_VERSION, "ArithmeticIntensity", LLVM_VERSION_STRING,
          [](PassBuilder &PB) {
            PB.registerPipelineParsingCallback(
                [](StringRef Name, FunctionPassManager &FPM,
                   ArrayRef<PassBuilder::PipelineElement>) {
                  if (Name == "arithmetic-intensity") {
                    FPM.addPass(ArithmeticIntensity());
                    return true;
                  }
                  return false;
                });
          }};
}

extern "C" LLVM_ATTRIBUTE_WEAK::llvm::PassPluginLibraryInfo
llvmGetPassPluginInfo() {
  return getArithmeticIntensityPluginInfo();
}