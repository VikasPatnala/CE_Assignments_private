# CS20BTECH11037
For this assignment 1a
My assumptions are
1. I am taking all the arithmetic operations(integer, floating) not only floating points operations
2. I assumed that the loop doesn't have any break statements and loop has very basic condition with constants

The working status of the code is it can print the arithmetic intensity of the IR and no of loops and how many times they iterate and I need to implement the loop case it is still pending because the loop can contain main contraints to include all those constraints and write our pass it is very difficult so we need other passes such as loopinfo.

To run the assignment just use the command provided in the Assignment document